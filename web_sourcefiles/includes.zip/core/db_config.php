<?php
 
/*
 * All database connection variables
 */
 
define('DB_USER', "a9192235_taxi"); // db user
define('DB_PASSWORD', "a9192235_taxi"); // db password (mention your db password here)
define('DB_DATABASE', "a9192235_taxi"); // database name
define('DB_SERVER', "mysql13.000webhost.com"); // db server
?>